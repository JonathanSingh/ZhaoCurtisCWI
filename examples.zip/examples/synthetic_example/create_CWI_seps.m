true_loc=load('true_loc.csv');
nevent=size(true_loc,1);
X_true=true_loc(:,1); Y_true=true_loc(:,2); Z_true=true_loc(:,3);
veloc_S=2298;
domin_freq=4.3;
domin_wavelength=veloc_S/domin_freq;
a_mu1=[0.4661 48.9697 2.4693 4.2467 1.1619];
a_sigma1=[0.1441 101.0376 120.3864 2.8430 6.0823]; c=0.017;
num_event=size(X_true,1);
num_pair=((num_event-1)+1)*(num_event-1)/2;
true_S_non_normalised=zeros(num_pair,1);
ii=1; jj=1; pair_index=1;
for ii=1:(size(X_true,1)-1)
    for jj=(ii+1):size(X_true,1)
        x=[X_true(ii);X_true(jj)];y=[Y_true(ii);Y_true(jj)];z=[Z_true(ii);Z_true(jj)];
        true_S_non_normalised(pair_index)=sqrt((x(1)-x(2)).^2+(y(1)-y(2)).^2+(z(1)-z(2)).^2);
        pair_index=pair_index+1;
    end 
end 
true_S=true_S_non_normalised/domin_wavelength;
MU_n_normalised=a_mu1(1).*(a_mu1(2).*true_S.^a_mu1(4)+a_mu1(3).*true_S.^a_mu1(5))./(a_mu1(2).*true_S.^a_mu1(4)+a_mu1(3).*true_S.^a_mu1(5)+1);
SIGMA_n_normalised= c+a_sigma1(1).*(a_sigma1(2).*true_S.^a_sigma1(4)+a_sigma1(3).*true_S.^a_sigma1(5))./(a_sigma1(2).*true_S.^a_sigma1(4)+a_sigma1(3).*true_S.^a_sigma1(5)+1);
MU_n=MU_n_normalised*domin_wavelength;
SIGMA_n=SIGMA_n_normalised*domin_wavelength;

xlswrite('CWI_separation_mean',MU_n)
xlswrite('CWI_separation_std',SIGMA_n)
