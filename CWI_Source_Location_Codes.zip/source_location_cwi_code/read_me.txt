When publishing using results produced with codes (original or edited) 
contained in this package, users should cite Zhao et al. (2017) and 
Zhao and Curtis (submitted, 2018).


References:
Zhao, Y., A. Curtis, B. Baptie, 2017, Locating micro-seismic sources with 
a single seismometer channel using coda wave interferometry: Geophysics, 
82, A19-A24.

Zhao, Y., and A. Curtis, 2018, Relative source location using coda wave 
interferometry: method, code package and application to mining induced 
earthquakes, submitted to Geophysics
