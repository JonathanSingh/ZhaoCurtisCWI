figure,subplot(1,3,1),plot(X_mod1,Y_mod1,'k*','markerfacecolor','k','markersize',8)
hold on; plot(X_rot2,Y_rot2,'ko','markersize',8)
hold on;ii=1;
for ii=1:num_event
    plot([X_mod1(ii) X_rot2(ii)],[Y_mod1(ii) Y_rot2(ii)],'-k');ii=ii+1;
end;hold on
xlabel('X(m)','fontsize',18); ylabel('Y(m)','fontsize',18)
grid on;daspect([1 1 1]);set(gca,'fontsize',15)
x_neg=min([X_mod1;X_rot2]);x_pos=max([X_mod1;X_rot2]);
y_neg=min([Y_mod1;Y_rot2]);y_pos=max([Y_mod1;Y_rot2]);
x_wide=abs(x_neg)+abs(x_pos); y_wide=abs(y_neg)+abs(y_pos);
[wide_plt,wide_axis]=max([x_wide y_wide]);  
if x_wide>=y_wide
    width_diff=(x_wide-y_wide)/y_wide;
    axis([x_neg-0.15*wide_plt x_pos+0.15*wide_plt y_neg*(1+width_diff)-0.15*wide_plt y_pos*(1+width_diff)+0.15*wide_plt]);
else
    width_diff=(y_wide-x_wide)/x_wide;
    axis([x_neg*(1+width_diff)-0.15*wide_plt x_pos*(1+width_diff)+0.15*wide_plt y_neg-0.15*wide_plt y_pos+0.15*wide_plt]);
end

subplot(1,3,2),plot(X_mod1,Z_mod1,'k*','markerfacecolor','k','markersize',8)
hold on; plot(X_rot2,Z_rot2,'ko','markersize',8)
hold on;ii=1;
for ii=1:num_event
    plot([X_mod1(ii) X_rot2(ii)],[Z_mod1(ii) Z_rot2(ii)],'-k');ii=ii+1;
end;hold off
xlabel('Y(m)','fontsize',18); ylabel('Z(m)','fontsize',18)
grid on;daspect([1 1 1]);set(gca,'fontsize',15)
x_neg=min([X_mod1;X_rot2]);x_pos=max([X_mod1;X_rot2]);
y_neg=min([Z_mod1;Z_rot2]);y_pos=max([Z_mod1;Z_rot2]);
x_wide=abs(x_neg)+abs(x_pos); y_wide=abs(y_neg)+abs(y_pos);
[wide_plt,wide_axis]=max([x_wide y_wide]);  
if x_wide>=y_wide
    width_diff=(x_wide-y_wide)/y_wide;
    axis([x_neg-0.15*wide_plt x_pos+0.15*wide_plt y_neg*(1+width_diff)-0.15*wide_plt y_pos*(1+width_diff)+0.15*wide_plt]);
else
    width_diff=(y_wide-x_wide)/x_wide;
    axis([x_neg*(1+width_diff)-0.15*wide_plt x_pos*(1+width_diff)+0.15*wide_plt y_neg-0.15*wide_plt y_pos+0.15*wide_plt]);
end

subplot(1,3,3),plot(Y_mod1,Z_mod1,'k*','markerfacecolor','k','markersize',8)
hold on; plot(Y_rot2,Z_rot2,'ko','markersize',8)
hold on;ii=1;
for ii=1:num_event
    plot([Y_mod1(ii) Y_rot2(ii)],[Z_mod1(ii) Z_rot2(ii)],'-k');ii=ii+1;
end;hold off
xlabel('Z(m)','fontsize',18); ylabel('X(m)','fontsize',18)
grid on;daspect([1 1 1]);set(gca,'fontsize',15)
x_neg=min([Y_mod1;Y_rot2]);x_pos=max([Y_mod1;Y_rot2]);
y_neg=min([Z_mod1;Z_rot2]);y_pos=max([Z_mod1;Z_rot2]);
x_wide=abs(x_neg)+abs(x_pos); y_wide=abs(y_neg)+abs(y_pos);
[wide_plt,wide_axis]=max([x_wide y_wide]);  
if x_wide>=y_wide
    width_diff=(x_wide-y_wide)/y_wide;
    axis([x_neg-0.15*wide_plt x_pos+0.15*wide_plt y_neg*(1+width_diff)-0.15*wide_plt y_pos*(1+width_diff)+0.15*wide_plt]);
else
    width_diff=(y_wide-x_wide)/x_wide;
    axis([x_neg*(1+width_diff)-0.15*wide_plt x_pos*(1+width_diff)+0.15*wide_plt y_neg-0.15*wide_plt y_pos+0.15*wide_plt]);
end




