clear all
% Basic parameters
veloc_S=2298;
domin_freq=4.3;
domin_wavelength=veloc_S/domin_freq
nevent=50;
num_channel=1;
num_pair=(1+(nevent-1))*(nevent-1)/2;
max_iteration=240;
L_tolerance=1e-5;

% Separation data
MU_n=load('CWI_separation_mean.csv');   % created by running script create_CWI_seps.m
SIGMA_n=load('CWI_separation_std.csv'); % created by running script create_CWI_seps.m
select_e_pair

% Initialization
initial_loc=load('inital_loc.csv');

% Source location
[ optm_loc, Func_L_add] = Source_Location( initial_loc,MU_n,SIGMA_n,domin_wavelength,discarded_pairs,max_iteration,L_tolerance );

% Save location results
xlswrite('optm_loc',optm_loc)

%% Display results
optm_loc=load('optm_loc.csv');
true_loc=load('true_loc.csv');
num_event=size(optm_loc,1);

% Adjust coordinates of true locations and recovered locations for visual comparison
[X_mod1,Y_mod1,Z_mod1]=coordinate_modify(optm_loc(:,1),optm_loc(:,2),optm_loc(:,3),num_event);
[X_mod2,Y_mod2,Z_mod2]=coordinate_modify(true_loc(:,1),true_loc(:,2),true_loc(:,3),num_event);
plot_modified_locations





