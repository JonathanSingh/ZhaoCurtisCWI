function Pr=rot3d(P,origin,dirct,theta)
% This function rotates point P about an axis (a stright line) which passes through a point
% called "origin" a direction vector called "direct", by angle theta
% P: a collection of coordinates of the points to be rotated (a nx3 matrix)
% origin: the point that the axis passes (a 1x3 vector)
% direct: the direction vector of the axis (a 1x3 vector)
% theta: the angle 

dirct=dirct(:)/norm(dirct);

A_hat=dirct*dirct';

A_star=[0,-dirct(3),dirct(2)
        dirct(3),0,-dirct(1)
       -dirct(2),dirct(1),0];
I=eye(3);
M=A_hat+cos(theta)*(I-A_hat)+sin(theta)*A_star;
origin=repmat(origin(:)',size(P,1),1);
Pr=(P-origin)*M'+origin;

