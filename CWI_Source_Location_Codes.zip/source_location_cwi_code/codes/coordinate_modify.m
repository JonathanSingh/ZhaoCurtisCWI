function [X4,Y4,Z4]=coordinate_modify(X,Y,Z,num_event)
% coordinate_modify.m adjusts the coordinate system of event cluster to 
% remove the ambiguity, following four steps (Robinson et al., 2013):

% Step 1: Move the cluster so that event1 is at the origin, i.e. e1=(0,0,0);

% Step 2: Rotate the cluster so that event2 lies on positive x-axis, i.e. 
% e2=(x2,0,0), where x2>0;

% Step 3: Rotate the cluster so that event3 lies in x-y plane, and
% y-coordinate>0, i.e. e3=(x3,y3,0), where y3>0;

% Step 4: Make sure that event 4 z-coordinate>0, i.e, e4=(x4,y4,z4), where 
% z4>0.


% Input:  
% X (Y,Z)                 N x 1 array, storing the x (y,z)-coordinate of 
%                         the event locations to be adjusted 

% num_event               number of events in the cluster


% Output:
% X4 (Y4,Z4)              N x 1 array, storing the x (y,z)-coordinate of 
%                         the adjusted event locations


% Scripts/Functions required:
% rot3d.m 
% (Source: LaterComer of MATLAB
% http://www.matlabsky.com/thread-18841-1-1.html
% retrieved in March 2015)


% References:
% Robinson, D. J., M. Sambridge, R. Snieder, and J. Hauser, 2013,
% Relocating a Cluster of Earthquakes Using a Single Seismic Station:
% Bulletin of the Seismological Society of America, 103, 3057-3072.


% Youqian Zhao, Sepetember 2017


% Step 1: Move the cluster so that event1 is at the origin
X_trans=X(1)-0; Y_trans=Y(1)-0; Z_trans=Z(1)-0;
X1=X-X_trans; Y1=Y-Y_trans; Z1=Z-Z_trans; 

% Step 2: Rotate the cluster so that event2 lies on positive x-axis
angle1=atan(Y1(2)/Z1(2));
Y2=Y1.*cos(angle1)-Z1.*sin(angle1);
Z2=Y1.*sin(angle1)+Z1.*cos(angle1);
X2=X1;
angle2=atan(Z2(2)/X2(2));
Z3=Z2.*cos(angle2)-X2.*sin(angle2);
X3=Z2.*sin(angle2)+X2.*cos(angle2);
Y3=Y2;
% Make sure x2>0
if X3(2)<0
    X3(2:end)=-X3(2:end);
else
end
if Z3(3)<0
    Z3(3:end)=-Z3(3:end);
else
end
Location3=[X3 Y3 Z3];

% Step 3: Rotate the cluster so that event3 lies in x-y plane, and y3>0
% Calculate the angle by which the cluster should rotate about axis e1-e2
vec_rotate_axis=[X3(2)-0 Y3(2)-0 Z3(2)-0];
vec_e3_point_on_axis=[X3(3) Y3(3) Z3(3)]-[X3(2) Y3(2) Z3(2)]; 
proj_on_axis=dot(vec_rotate_axis,vec_e3_point_on_axis)/norm(vec_rotate_axis);
Distance_e3_axis=sqrt(abs((norm(vec_e3_point_on_axis))^2-(proj_on_axis)^2));
Distance_e3_plane=abs(Z3(3));
theta_angle=asin(Distance_e3_plane/Distance_e3_axis);
theta_angle_in_degree=theta_angle*180/pi;
% Rotate the cluster about axis e1-e2 by theta_angle
origin=[X3(2) Y3(2) Z3(2)];
direct=vec_rotate_axis;
theta=theta_angle;
P=[X3(3:end) Y3(3:end) Z3(3:end)];
Location4=zeros(num_event,3);
Location4(1:2,:)=Location3(1:2,:);
if Y3(3)<0
    Location4(3:end,:)=rot3d(P,origin,direct,theta);
else
    Location4(3:end,:)=rot3d(P,origin,direct,-theta);
end
X4=Location4(:,1); Y4=Location4(:,2); Z4=Location4(:,3);
% Make sure z3>0
if Y4(3)<0
    Y4(3:end)=-Y4(3:end);
else
end

% Step 4: Make sure that event 4 z-coordinate>0
if Z4(4)<0
    Z4(4:end)=-Z4(4:end);
else
end
Location4=[X4 Y4 Z4];


end

