% std_maxtrix_3d.m generates a three-dimensional matrix. Each element is
% the average standard deviation of inter-source separations over all
% available pairs in the given cluster recorded by the given station channel(s).

% std_maxtrix_3d.m is called in separtion_parameters.m.

% Scripts/Functions required:
% std_matrix_element.m
%     CWI_sep.m

% Output:
% STD_matrix_3D      a three-dimensional matrix. Each element is the average standard deviation of
%                    inter-source separations over all available pairs in the given cluster recorded
%                    by the given station channel(s), calculated with one possible combination of
%                    [number, length, starting time] of time-windows
%                          dimension 1: possible number of time-windows
%                          dimension 2: possible length of time-windows
%                          dimension 3: possible starting time of windowing

% Youqian Zhao, Sepetember 2017


%% Decide the size of STD_matrix_3D
max_l_coda=coda_end-coda_start;
max_num_win_possible=floor(max_l_coda/min_l_win);
if max_num_win_possible>=max_num_win_limit
    max_num_win_possible=max_num_win_limit;
else
end
d1=(max_num_win_possible-min_num_win)+1;  % d1: largest number of possible num_win
d2=floor((max_l_win_allowed-min_l_win)/dl_win)+1; % d2: largest number of possible l_win
win_start_coll=coda_start:dl_coda_start:(coda_end-min_l_win*min_num_win); % coll: 'collection'
d3=numel(win_start_coll);  % d3: largest number of possible starting time of windowing
STD_matrix_3D=zeros(d1,d2,d3);


%% Compute STD_matrix_3D
l_win_possible=min_l_win:dl_win:max_l_win_allowed;
ii=1;
for ii=1:d3 % loop over all available starting time of windowing
    
    % Work out all possible window lengths for the current staring time of windowing
    start_win=win_start_coll(ii);
    l_coda=coda_end-start_win;
    l_win_coll_max=min_l_win;
    l_win_coll_length=1;
    while l_win_coll_max<floor((l_coda/min_num_win)/dl_win)*dl_win && (l_win_coll_length<=numel(l_win_possible))
        l_win_coll_max=l_win_possible(l_win_coll_length);
        l_win_coll_length=l_win_coll_length+1;
    end
    if l_win_coll_length>1
        l_win_coll_length=l_win_coll_length-1;
    else
    end
    l_win_coll=l_win_possible(1:l_win_coll_length);
    jj=1;
    for jj=1:d2 % loop over all available window lengths for the current staring time of windowing
        
        % Work out all possible window numbers for the current window length and starting time of windowing
        if jj>l_win_coll_length
            STD_matrix_3D(:,jj,ii)=Large_marking_number; % Mark the elements whose window length is beyond the searching range
        else
            l_win=l_win_coll(jj);
            num_win_coll=min_num_win:floor(l_coda/l_win);
            kk=1;
            for kk=1:d1 % loop over all available window numbers for the current window length and staring time of windowing
                if kk>numel(num_win_coll)
                    STD_matrix_3D(kk,jj,ii)=Large_marking_number; % Mark the elements whose window number is beyond the searching range
                else
                    num_win=num_win_coll(kk);
                    end_win=start_win+l_win*num_win;
                    
                    % Compute the matrix element with the current parameter combination
                    std_matrix_element
                    STD_matrix_3D(kk,jj,ii)=STD_mean;
                end
                kk=kk+1;
            end
        end
        jj=jj+1;
    end
    ii=ii+1;
end

% Ignore the matrix elements whose parameter combination is beyond the searching range
ii=1;
for ii=1:numel(STD_matrix_3D)
    if  STD_matrix_3D(ii)>Large_marking_number-1
        STD_matrix_3D(ii)=nan;
    else
    end
    ii=ii+1;
end


