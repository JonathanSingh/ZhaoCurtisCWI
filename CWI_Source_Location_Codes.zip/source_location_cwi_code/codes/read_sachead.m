function [ sachead ] = read_sachead( filename )
% read_sachead retrieves header of SAC files .

% input: 
% filename            name of the SAC file to read

% output: 
% sachead             header of SAC file 

% Scripts/Functions required:
% sac.m
% sachdr.m
% (Source: Seismic Analysis Code (SAC)
% http://geophysics.eas.gatech.edu/people/zpeng/Teaching/Sac_Tutorial_2006/
% retrieved in April 2015)

% Youqian Zhao, Sepetember 2017


[head1,head2,head3]=sac(filename);
[sachead]=sachdr(head1,head2,head3);

end

