function [ time,data,hdrsac] = read_sac( filename )
% read_sac.m reads SAC files.

% input: 
% filename            name of the SAC file to read

% output: 
% time                time array of the waveform
% data                waveform data
% hdrsac              header of SAC file 

% Scripts/Functions required:
% sac.m
% sachdr.m
% (Source: Seismic Analysis Code (SAC)
% http://geophysics.eas.gatech.edu/people/zpeng/Teaching/Sac_Tutorial_2006/
% retrieved in April 2015)

% Youqian Zhao, Sepetember 2017


[head1,head2,head3,data]=sac(filename);
[hdrsac]=sachdr(head1,head2,head3);
time = [hdrsac.times.b:hdrsac.times.delta:(hdrsac.data.trcLen-1)*hdrsac.times.delta+hdrsac.times.b]';
end

