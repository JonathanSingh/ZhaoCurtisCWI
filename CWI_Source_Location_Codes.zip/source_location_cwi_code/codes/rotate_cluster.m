% rotate_cluster.m rotates a cluster of points about its center in two
% orthogonal directions in the 3D space by given angles.


% Input:
% P0                   n x 3 array, storing the original point coordinates,
%                      n being the number of points to rotate

% alpha                angel by which the cluster rotates anticlockwise when observed from 
%                      above about a line passing the cluster center and parallel to z-axis.

% theta                angel by which the cluster rotates anticlockwise about a line passing 
%                      the cluster center and parallel to x-axis.


% Output:
% P_rotate             n x 3 array, storing the rotated point coordinates,
%                      n being the number of points to rotate


% Scripts/Functions required:
% rot3d.m


% Youqian Zhao, Sepetember 2017


function [ P_rotate ] = rotate_cluster( P0, alpha, theta )

% Compute cluster center
C=mean(P0,1); 

% Rotate the cluster about a line passing the cluster center and parallel to z-axis
P1=rot3d(P0,C,[C(1)-C(1) C(2)-C(2) 1],alpha);

% Rotate the cluster about a line passing the cluster center and parallel to x-axis
P2=rot3d(P1,C,[1 C(2)-C(2) C(3)-C(3)],theta);
P_rotate=P2;
end

