function [ prob_indiviudal ] = likelihood_individual(x,y,z, domin_wavelength,a_mu1,a_sigma1,c,mu_n,sigma_n)
% likelihood_individual.m estimates the likelihood function 
% P(delta_CWIN|delta_true) for an individual pair of events (Robinson et 
% al. 2011), which is the likelihood of having observed delta_CWIN, given 
% the true separation being delta_true.

% The positively-bounded Gaussian distributions are approximated with 
% Gaussian distributions to save computational time. This is reasonable 
% because in this function here, the source separation data are used as 
% their own, which are much greater then zero, instead of their normalized 
% version as by Robinson et al. (2011).


% Input:
% x (y, z)                x (y, z)-axis coordinates of the location of the two events

% domin_wavelength        dominate wavelength of the propagating waves

% a_mu1                   parameters of the empirical relation between true 
%                         separation and the mean of the CWI estimates 

% a_sigma1,c              parameters of the empirical relation between true 
%                         separation and the standard deviation of the CWI estimates

% mu_n                    the mean of the CWI separation estimates

% sigma_n                 the standard deviation of the CWI separation estimates


% Output:
% prob_indiviudal         the noisy likelihood P(delta_CWIN|delta_true) of an individual 
%                         pair of events 
 

% References:
%     Robinson, D. J., M. Sambridge, and R. Snieder, 2011, A probabilistic
% approach for estimating the separation between a pair of earthquakes
% directly from their coda waves: Journal of Geophysical Research, 116,1-14.
%     Robinson, D. J., M. Sambridge, R. Snieder, and J. Hauser, 2013, 
% Relocating a Cluster of Earthquakes Using a Single Seismic Station: 
% Bulletin of the Seismological Society of America, 103, 3057-3072.


% Youqian Zhao, Sepetember 2017


% Calculate source separation based on the current event locations
true_sep=sqrt((x(1)-x(2)).^2+(y(1)-y(2)).^2+(z(1)-z(2)).^2); % the true separation based on the current event locations
true_sep_nor=true_sep/domin_wavelength; % the normalized true separation

% Work out the mean and standard deviation of the CWI estimates given the 
% true separation, using the empirical relations
mu1_normalized=a_mu1(1)*(a_mu1(2)*true_sep_nor.^a_mu1(4)+a_mu1(3)*true_sep_nor.^a_mu1(5))/(a_mu1(2)*true_sep_nor.^a_mu1(4)+a_mu1(3)*true_sep_nor.^a_mu1(5)+1);
sigma1_normalized= c+a_sigma1(1)*(a_sigma1(2)*true_sep_nor.^a_sigma1(4)+a_sigma1(3)*true_sep_nor.^a_sigma1(5))/(a_sigma1(2)*true_sep_nor.^a_sigma1(4)+a_sigma1(3)*true_sep_nor.^a_sigma1(5)+1);
mu1=mu1_normalized*domin_wavelength;
sigma1=sigma1_normalized*domin_wavelength;

% Estimate the likelihood P(delta_CWIN|delta_true)
h3=0.014; % integral increment        
upper_bound_2=700; % the upper bound of the integral
% The following representations follows the terms used in Appedix of
% Robinson et al. (2013)
A=1/(sigma1*sqrt(2*pi));
C=1/(sigma_n*sqrt(2*pi));
delta_cwi=0:h3:upper_bound_2;
B=exp(-(delta_cwi-mu1).^2./(2*sigma1.^2));
D=exp(-(delta_cwi-mu_n).^2./(2*sigma_n.^2));
B_x_D=B.*D;
integrand_3=A*C*(0.5*(B_x_D(1)+B_x_D(end))+sum(B_x_D(2:end-1)))*h3;
prob_indiviudal=integrand_3;

end



