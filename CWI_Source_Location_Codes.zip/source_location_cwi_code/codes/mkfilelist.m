if isempty(dir('filelist.txt'))==0
    delete filelist.txt
else
end

lis=dir('*SAC');
num_file=size(lis,1);
fileID=fopen('filelist.txt','a')
ii=1;
for ii=1:num_file
    fprintf(fileID,'%s  %i\n',lis(ii).name,ii);
    ii=ii+1;
end
fclose(fileID)