function [ lambda_step ,fvalue_new ] = line_search( Xc,Yc,Zc, dc,domin_wavelength,min_lambda_coarse,max_lambda_coarse,delta_lambda_coarse,delta_lambda_dense, a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs)
% line_search.m conducts searches for the minimum of an objective function 
% L in a given direction in three steps:

% 1) Along the given direction, evaluate function L in a large range with 
% increments of delta_lambda_coarse, and find the (coarse) minimum among these 
% values of L.

% 2) Define a smaller range around the minimum found, evaluate function L 
% in the smaller range with increments of delta_lamba_dense, and find a new
% (dense) minimum among these values of L.

% 3) Adjust the dense minimum by fitting a parabola using the minimum point found 
% and two of its adjacent points, and take the vertex of the parabola as 
% the final minimum of L along the given direction.


% Input:
% Xc (Yc,Zc)              x (y, z)-axis coordinates of the current location of
%                         events in the cluster

% dc                      current searching direction

% domin_wavelength        dominate wavelength of the propagating waves

% min_lambda_coarse       lower bound of the large (coarse) searching range 

% max_lambda_coarse       upper bound of the large (coarse) searching range 

% delta_lambda_coarse     increment of the large (coarse) searching range 

% delta_lambda_dense      increment of the small (dense) searching range 

% a_mu1                   parameters of the empirical relations between true
%                         separation and the mean of the CWI estimates

% a_sigma1,c              parameters of the empirical relations between true
%                         separation and the standard deviation of the CWI estimates

% MU_n                    N(N-1)/2 x K array, each column storing the means of the
%                         CWI separation estimates for all available event pairs, with 
%                         N being the number of events, K being the number of channels

% SIGMA_n                 N(N-1)/2 x K array, each columnstoring the standard
%                         deviations of the CWI separation estimates for all available 
%                         event pairs

% discarded_pairs         indices of event pairs to be discarded
%                               []        - no pair to be discarded
%                               nx1 array - single channle case,
%                                           with n pair(s) to be discarded
%                               nxK array - K channle case,
%                                           with n being the largest number of pairs 
%                                           to be discarded for any individual channel


% Output:
% lambda_step             step length the current iteration should take to attain the 
%                         minimum in the given searching direction 

% fvalue_new              value of function L at the minimum found in the given 
%                         searching direction 


% Scripts/Functions required:
% ln_joint_likelihood.m
% likelihood_individual.m


% Youqian Zhao, Sepetember 2017


%% Step 1
% Evaluate L in the given coarse range
lambda_step_coarse=min_lambda_coarse:delta_lambda_coarse:max_lambda_coarse;
function_value_coarse=zeros(length(lambda_step_coarse),1);
jj=1;
parfor jj=1:length(lambda_step_coarse)
    X_new=Xc+dc(:,1).*lambda_step_coarse(jj); 
    Y_new=Yc+dc(:,2).*lambda_step_coarse(jj); 
    Z_new=Zc+dc(:,3).*lambda_step_coarse(jj);   
    function_value_coarse(jj)=ln_joint_likelihood( X_new,Y_new,Z_new,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
end 
% Find the coarse minimum 
[min_func_coarse,min_lambda_coarse_index]=min(function_value_coarse);


%% Step 2 & Step 3
% If the coarse minimum is found at the lower bound of the coarse range,
% the dense searchng range is the range between (and include) the lower 
% bound and one coarse increment after it.
if min_lambda_coarse_index==1
    
    % Step 2: 
    % Define the smaller seaching range
    lambda_step_dense=lambda_step_coarse(1):delta_lambda_dense:lambda_step_coarse(2);
    function_value_dense=zeros(1,length(lambda_step_dense));
    % Evaluate function L in the smaller range
    function_value_dense(1)=function_value_coarse(1);
    function_value_dense(length(lambda_step_dense))=function_value_coarse(2);
    ii=2;
    parfor ii=2:length(lambda_step_dense)-1 
        X_new=Xc+dc(:,1).*lambda_step_dense(ii); Y_new=Yc+dc(:,2).*lambda_step_dense(ii); Z_new=Zc+dc(:,3).*lambda_step_dense(ii);     
        function_value_dense(ii)=ln_joint_likelihood( X_new,Y_new,Z_new,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n,  discarded_pairs);
    end
    % Find the dense minimum 
    [min_func_dense,min_lambda_dense_index]=min(function_value_dense);
    
    % Step 3: 
    % Choose three point to fit parabola
    if min_lambda_dense_index==1
       x_data=lambda_step_dense(1:3); 
       y_data=function_value_dense(1:3);
    elseif min_lambda_dense_index>1 & min_lambda_dense_index<length(lambda_step_dense)
       x_data=lambda_step_dense(min_lambda_dense_index-1:min_lambda_dense_index+1); 
       y_data=function_value_dense(min_lambda_dense_index-1:min_lambda_dense_index+1);
    else 
        x_data=lambda_step_dense(end-2:end); 
        y_data=function_value_dense(end-2:end);
    end
    % Fit a parabola
    [p,s]=polyfit(x_data,y_data,2); 
    min_positon=-p(2)/(2*p(1));
    % Take the vertex as the final minimum
    lambda_step=min_positon;
    % Update the value of L
    fvalue_new = polyval(p,min_positon,s)
    
    
% If the coarse minimum is found between the lower and upper bound of the
% coarse range, the dense searchng range is defined by (and include) the found minimum
% minus and plus one coarse increment.
elseif min_lambda_coarse_index>1 & min_lambda_coarse_index<length(lambda_step_coarse)
    
    % Step 2: 
    % Define the smaller seaching range
    lambda_step_dense=lambda_step_coarse(min_lambda_coarse_index-1):delta_lambda_dense:lambda_step_coarse(min_lambda_coarse_index+1);
    function_value_dense=zeros(1,length(lambda_step_dense));
    % Evaluate function L in the smaller range
    function_value_dense(1)=function_value_coarse(min_lambda_coarse_index-1);
    function_value_dense(length(lambda_step_dense))=function_value_coarse(min_lambda_coarse_index+1);
    ii=2;
    parfor ii=2:length(lambda_step_dense)-1 
        X_new=Xc+dc(:,1).* lambda_step_dense(ii) ;
        Y_new=Yc+dc(:,2).* lambda_step_dense(ii) ;
        Z_new=Zc+dc(:,3).* lambda_step_dense(ii) ;
        function_value_dense(ii)=ln_joint_likelihood( X_new,Y_new,Z_new,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
    end
    % Find the dense minimum 
    [min_func_dense,min_lambda_dense_index]=min(function_value_dense);
    
    % Step 3: 
    % Choose three point to fit parabola
    if min_lambda_dense_index==1
       x_data=lambda_step_dense(1:3); 
       y_data=function_value_dense(1:3);
    elseif min_lambda_dense_index>1 & min_lambda_dense_index<length(lambda_step_dense)
       x_data=lambda_step_dense(min_lambda_dense_index-1:min_lambda_dense_index+1); 
       y_data=function_value_dense(min_lambda_dense_index-1:min_lambda_dense_index+1);
    else 
        x_data=lambda_step_dense(end-2:end); 
        y_data=function_value_dense(end-2:end);
    end
    % Fit a parabola
    [p,s]=polyfit(x_data,y_data,2); 
    min_positon=-p(2)/(2*p(1));
    % Take the vertex as the final minimum
    lambda_step=min_positon;
    % Update the value of L
    fvalue_new = polyval(p,min_positon,s)
    

% If the coarse minimum is found at the upper bound of the coarse range,
% the dense searchng range is the range between (and include) one coarse 
% increment before the upper bound and the upper bound.
else 
    
    % Step 2: 
    % Define the smaller seaching range
    lambda_step_dense=lambda_step_coarse(end-1):delta_lambda_dense:lambda_step_coarse(end);
    function_value_dense=zeros(1,length(lambda_step_dense));
    % Evaluate function L in the smaller range
    function_value_dense(1)=function_value_dense(end);
    function_value_dense(length(lambda_step_dense))=function_value_dense(end-1);
    ii=2;
    parfor ii=2:length(lambda_step_dense)-1
        X_new=Xc+dc(:,1).* lambda_step_dense(ii) ;
        Y_new=Yc+dc(:,2).* lambda_step_dense(ii) ;
        Z_new=Zc+dc(:,3).* lambda_step_dense(ii);
        function_value_dense(ii)=ln_joint_likelihood( X_new,Y_new,Z_new,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
    end
    % Find the dense minimum 
    [min_func_dense,min_lambda_dense_index]=min(function_value_dense);
    
    % Step 3: 
    % Choose three point to fit parabola
    if min_lambda_dense_index==1
       x_data=lambda_step_dense(1:3);
       y_data=function_value_dense(1:3);
    elseif min_lambda_dense_index>1 & min_lambda_dense_index<length(lambda_step_dense)
       x_data=lambda_step_dense(min_lambda_dense_index-1:min_lambda_dense_index+1); 
       y_data=function_value_dense(min_lambda_dense_index-1:min_lambda_dense_index+1);
    else 
        x_data=lambda_step_dense(end-2:end); 
        y_data=function_value_dense(end-2:end);
    end
    % Fit a parabola
    [p,s]=polyfit(x_data,y_data,2); 
    min_positon=-p(2)/(2*p(1));
    % Take the vertex as the final minimum
    lambda_step=min_positon;
    % Update the value of L
    fvalue_new = polyval(p,min_positon,s)
end 

end

