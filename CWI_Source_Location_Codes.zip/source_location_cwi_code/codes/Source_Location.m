function [ optm_loc, Func_L_add] = Source_Location( initial_loc,MU_n,SIGMA_n,domin_wavelength,discarded_pairs,max_iteration,L_tolerance )

% Source_Location.m estimates the relative location of a cluster of events, 
% using inter-source separation data (their mean and standard deviations) 
% estimated with coda wave interferometry (CWI). The location is solved as 
% a minimization problem, where the most probable set of event locations 
% are found where the objective function L attains its minimum (Robinson et
% al., 2013). When using data from multiple channels, the joint likelihood 
% function proposed by Zhao et al. (2017) is used. 

% This function solves the minimization problem in three steps. For a given 
% location (Xi,Yi,Zi) (i=0,1,2,...,n, where n is the number of iteration):

% 1: Find the searching direction di:
%    steepest descent direction for i=0;
%    conjugate gradient for i>0.

% 2: Conduct a line search to find the step length lambdai leading to the 
% minimum of L in the current direction.

% 3: Update the current locations as X(i+1)=Xi+di*lambdai.

% Step 1-3 are repeated until one of the three criteria is met: 1) the 
% value of L is larger then that obtained in the last iteration; 2) the 
% gain (decrease in L) of an iteration is trivial; or 3) the maximum number 
% of iterations is reached


% Input:
% initial_loc             N x 3 array:
%                               column 1 - x-coordinates of the initial event locations
%                               column 2 - y-coordinates of the initial event locations
%                               column 3 - z-coordinates of the initial event locations

% MU_n                    N(N-1)/2 x K array, each column storing the means of the
%                         CWI separation estimates for all available event pairs, with 
%                         N being the number of events, K being the number of channels

% SIGMA_n                 N(N-1)/2 x K array, each columnstoring the standard
%                         deviations of the CWI separation estimates for all available 
%                         event pairs

% discarded_pairs         indices of event pairs to be discarded
%                               []        - no pair to be discarded
%                               nx1 array - single channel case,
%                                           with n pair(s) to be discarded
%                               nxK array - K channle case,
%                                           with n being the largest number of pairs 
%                                           to be discarded for any individual channel

% max_iteration           maximum number of iteration allowed

% L_tolerance             minimum decrease in the objective function, below which the iteration shall be terminated 


% Output:
% optm_loc                N x 3 array, storing the location results:
%                               column 1 - x-coordinates of the final event locations
%                               column 2 - y-coordinates of the final event locations
%                               column 3 - z-coordinates of the final event locations

% Func_L_add              m x 1 array, storing the value of L of after each iteration, 
%                         with m being the number of iterations

% Scripts/Functions required:
% line_search.m
% gradient.m
% ln_joint_likelihood.m
% likelihood_individual.m


% References:
%     Robinson, D. J., M. Sambridge, R. Snieder, and J. Hauser, 2013,
% Relocating a Cluster of Earthquakes Using a Single Seismic Station:
% Bulletin of the Seismological Society of America, 103, 3057-3072.
%     Zhao, Y., A. Curtis, and B. Baptie, 2017, Locating microseismic
% sources with a single seismometer channel using coda wave interferometry:
% Geophysics, 82, NO. 3, A19?A24, doi: 10.1190/GEO2016-0404.1.


% Youqian Zhao, Sepetember 2017


%% Pre-allocate space to store relevant variables 
X0=initial_loc(:,1); Y0=initial_loc(:,2); Z0=initial_loc(:,3);
num_event=numel(X0);
num_pair=((num_event-1)+1)*(num_event-1)/2;
Func_L=zeros(max_iteration,1);
max_lambda_coarse_collect=zeros(max_iteration,1);
delta_lambda_coarse_collect=zeros(max_iteration,1);
delta_lambda_dense_collect=zeros(max_iteration,1);
Lambda=zeros(max_iteration,1);
beta_PR=zeros(max_iteration,1);
Grad=zeros(num_event,3,max_iteration);
Direction=zeros(num_event,3,max_iteration);

% Set the parameters in the empirical relations between the mean (and
% standard deviations) of CWI separation estimates with the true separations
% For the mean
a_mu1=[0.4661 48.9697 2.4693 4.2467 1.1619];
% For the standard deviations
a_sigma1=[0.1441 101.0376 120.3864 2.8430 6.0823]; c=0.017;


%% Iteration 0
% Step1: work out searching direction - steepest descent direction
Xc=X0; Yc=Y0; Zc=Z0; 
Gradient0=gradient( Xc,Yc,Zc,domin_wavelength,  a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs );
d0=-Gradient0;

% Step2:
% Decide searching ranges for the line search in the current iteration
max_MU=max(max(MU_n));    
mean_d0=mean(reshape(abs(d0),num_event*3,1));
search_cap_lambda=max_MU/mean_d0;
min_lambda_coarse=0;  
max_lambda_coarse=search_cap_lambda/4;    
delta_lambda_dense=search_cap_lambda/4000;
delta_lambda_coarse_candidate=(2*delta_lambda_dense):(2*delta_lambda_dense):(max_lambda_coarse/2);
num_time_evl=max_lambda_coarse./delta_lambda_coarse_candidate+2*delta_lambda_coarse_candidate/delta_lambda_dense;
[min_num_run,min_num_run_ind]=min(num_time_evl);
delta_lambda_coarse=delta_lambda_coarse_candidate(min_num_run_ind);
if delta_lambda_coarse > 10*delta_lambda_dense   
    delta_lambda_coarse = 10*delta_lambda_dense;
else
end
% Line search    
dc=d0;
[ lambda_step0 ,fvalue_new0 ] = line_search( Xc,Yc,Zc,dc,domin_wavelength,min_lambda_coarse,max_lambda_coarse,delta_lambda_coarse,delta_lambda_dense, a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
max_lambda_coarse_0=max_lambda_coarse; 
delta_lambda_dense_0=delta_lambda_dense; 
delta_lambda_coarse_0=delta_lambda_coarse; 

% Step3: update event locations
XX=zeros(num_event,max_iteration); YY=zeros(num_event,max_iteration); ZZ=zeros(num_event,max_iteration); 
XX(:,1)=X0+d0(:,1).* lambda_step0 ; YY(:,1)=Y0+d0(:,2).* lambda_step0 ; ZZ(:,1)=Z0+d0(:,3).* lambda_step0;

%% Iteration i (i>0)
% Step1 (i=1): work out searching direction - conjugate gradient (Polak Ribiere)
Grad_old=Gradient0;
Grad_new=gradient(XX(:,1),YY(:,1),ZZ(:,1),domin_wavelength, a_mu1,a_sigma1,c, MU_n,SIGMA_n, discarded_pairs);
Grad(:,:,1)=Grad_new;
num_variavle=num_event*3;
Grad_old_reshape=reshape(Grad_old,num_variavle,1); Grad_old_resha_trans=(Grad_old_reshape)';
Grad_new_reshape=reshape(Grad_new,num_variavle,1); Grad_new_resha_trans=(Grad_new_reshape)';
beta_PR(1)=max([Grad_new_resha_trans*(Grad_new_reshape-Grad_old_reshape)/(Grad_old_resha_trans*Grad_old_reshape) 0]);
Direction(:,:,1)=-Grad(:,:,1)+beta_PR(1).*d0;

% Step2 (i=1):
% Decide searching ranges for the line search in the current iteration
mean_dc=mean(reshape(abs(Direction(:,:,1)),num_event*3,1));
search_cap_lambda=max_MU/mean_dc;
min_lambda_coarse=0;  
max_lambda_coarse=search_cap_lambda/4;    
delta_lambda_dense=search_cap_lambda/4000;
delta_lambda_coarse_candidate=(2*delta_lambda_dense):(2*delta_lambda_dense):(max_lambda_coarse/2);
num_time_evl=max_lambda_coarse./delta_lambda_coarse_candidate+2*delta_lambda_coarse_candidate/delta_lambda_dense;
[min_num_run,min_num_run_ind]=min(num_time_evl);
delta_lambda_coarse=delta_lambda_coarse_candidate(min_num_run_ind);
if delta_lambda_coarse > 10*delta_lambda_dense   
    delta_lambda_coarse = 10*delta_lambda_dense;
else
end
% Line search   
[ lambda_step1 ,fvalue_new1 ] = line_search(XX(:,1),YY(:,1),ZZ(:,1),Direction(:,:,1),domin_wavelength,min_lambda_coarse,max_lambda_coarse,delta_lambda_coarse,delta_lambda_dense, a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
Lambda(1)=lambda_step1;
max_lambda_coarse_collect(1)=max_lambda_coarse;
delta_lambda_coarse_collect(1)=delta_lambda_coarse;
delta_lambda_dense_collect(1)=delta_lambda_dense;
% Update relevant variables
L_initial=ln_joint_likelihood( X0,Y0,Z0,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
L_old=L_initial;
L_new=fvalue_new0;
Func_L(1)=L_new;

iteration_ind=2;
while (L_old-L_new > L_tolerance) && (iteration_ind <= max_iteration)
    L_old=L_new;
    Grad_old=Grad_new;
    
    % Step 3 (iteration i): update event locations 
    XX(:,iteration_ind)=XX(:,iteration_ind-1)+Direction(:,1,iteration_ind-1).*Lambda(iteration_ind-1);
    YY(:,iteration_ind)=YY(:,iteration_ind-1)+Direction(:,2,iteration_ind-1).*Lambda(iteration_ind-1);
    ZZ(:,iteration_ind)=ZZ(:,iteration_ind-1)+Direction(:,3,iteration_ind-1).*Lambda(iteration_ind-1);
    
    % Step 1 (iteration i+1): work out searching direction - conjugate gradient (Polak Ribiere): 
    Grad_new=gradient(XX(:,iteration_ind),YY(:,iteration_ind),ZZ(:,iteration_ind),domin_wavelength, a_mu1,a_sigma1,c,  MU_n,SIGMA_n, discarded_pairs); 
    Grad(:,:,iteration_ind)=Grad_new; 
    Grad_old_reshape=reshape(Grad_old,num_variavle,1);Grad_old_resha_trans=(Grad_old_reshape)';
    Grad_new_reshape=reshape(Grad_new,num_variavle,1);Grad_new_resha_trans=(Grad_new_reshape)';
    beta_PR(iteration_ind)=max([Grad_new_resha_trans*(Grad_new_reshape-Grad_old_reshape)/(Grad_old_resha_trans*Grad_old_reshape) 0]);
    Direction(:,:,iteration_ind)=-Grad(:,:,iteration_ind)+beta_PR(iteration_ind).*Direction(:,:,iteration_ind-1);
    
    % Step2 (iteration i+1):
    % Decide searching ranges for the line search in the current iteration
    mean_dc=mean(reshape(abs(Direction(:,:,iteration_ind)),num_event*3,1));
    search_cap_lambda=max_MU/mean_dc
    min_lambda_coarse=0;
    max_lambda_coarse=search_cap_lambda/4;    
    delta_lambda_dense=search_cap_lambda/4000;
    warning('off');
    if iteration_ind > 25
        if max_lambda_coarse>2*mean(max_lambda_coarse_collect(1:24))
            max_lambda_coarse=2*mean(max_lambda_coarse_collect(1:24));
        else
        end
    else
    end
    if iteration_ind > 25
        if delta_lambda_dense > 2*mean(delta_lambda_dense_collect(1:24))
            delta_lambda_dense = 2*mean(delta_lambda_dense_collect(1:24));
        else
        end       
    else
    end
    delta_lambda_coarse_candidate=(2*delta_lambda_dense):(2*delta_lambda_dense):(max_lambda_coarse/2);
    num_time_evl=max_lambda_coarse./delta_lambda_coarse_candidate+2*delta_lambda_coarse_candidate/delta_lambda_dense;
    [min_num_run,min_num_run_ind]=min(num_time_evl);
    delta_lambda_coarse=delta_lambda_coarse_candidate(min_num_run_ind);
    if delta_lambda_coarse > 10*delta_lambda_dense   
        delta_lambda_coarse = 10*delta_lambda_dense;
    else
    end
    % Line search 
    [ lambda_step ,fvalue_new ] = line_search(XX(:,iteration_ind),YY(:,iteration_ind),ZZ(:,iteration_ind), Direction(:,:,iteration_ind),domin_wavelength,min_lambda_coarse,max_lambda_coarse,delta_lambda_coarse,delta_lambda_dense, a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs);
    % Update relevant variables
    Lambda(iteration_ind)=lambda_step;
    max_lambda_coarse_collect(iteration_ind)=max_lambda_coarse;
    delta_lambda_coarse_collect(iteration_ind)=delta_lambda_coarse;
    delta_lambda_dense_collect(iteration_ind)=delta_lambda_dense;
    L_new=fvalue_new; 
    Func_L(iteration_ind)=L_new;
    
    iteration_ind=iteration_ind+1
end
iteration_ind=iteration_ind-1;


%% Adjust the size of relevant variables according to the number of iterations
% If the iterations stoped becuase criterion 2 or 3 was reached
if L_old>=L_new  
    L_final=L_new;
    Func_L=Func_L(1:iteration_ind);
    Func_L_add=[L_initial;Func_L]; 
    Lambda=Lambda(1:iteration_ind);
    Lambda_add=[lambda_step0;Lambda]; 
    max_lambda_coarse_collect=max_lambda_coarse_collect(1:iteration_ind);
    max_lambda_coarse_collect_add=[max_lambda_coarse_0;max_lambda_coarse_collect];
    delta_lambda_coarse_collect=delta_lambda_coarse_collect(1:iteration_ind);
    delta_lambda_coarse_collect_add=[delta_lambda_coarse_0;delta_lambda_coarse_collect]; 
    delta_lambda_dense_collect=delta_lambda_dense_collect(1:iteration_ind);
    delta_lambda_dense_collect_add=[delta_lambda_dense_0;delta_lambda_dense_collect];   
    XXX=XX(:,1:iteration_ind); YYY=YY(:,1:iteration_ind); ZZZ=ZZ(:,1:iteration_ind);
    Grad=Grad(:,:,1:iteration_ind); beta_PR=beta_PR(1:iteration_ind); Direction=Direction(:,:,1:iteration_ind);
    num_iteration=iteration_ind;
% If the iterations stoped becuase criterion 1 was reached
else           
    L_final=L_old;
    Func_L=Func_L(1:iteration_ind-1);
    Func_L_add=[L_initial;Func_L];
    Lambda=Lambda(1:iteration_ind-1);
    Lambda_add=[lambda_step0;Lambda]; 
    max_lambda_coarse_collect=max_lambda_coarse_collect(1:iteration_ind-1);
    max_lambda_coarse_collect_add=[max_lambda_coarse_0;max_lambda_coarse_collect];
    delta_lambda_coarse_collect=delta_lambda_coarse_collect(1:iteration_ind-1);
    delta_lambda_coarse_collect_add=[delta_lambda_coarse_0;delta_lambda_coarse_collect];
    delta_lambda_dense_collect=delta_lambda_dense_collect(1:iteration_ind-1);
    delta_lambda_dense_collect_add=[delta_lambda_dense_0;delta_lambda_dense_collect];
    XXX=XX(:,1:iteration_ind-1); YYY=YY(:,1:iteration_ind-1); ZZZ=ZZ(:,1:iteration_ind-1);
    Grad=Grad(:,:,1:iteration_ind-1); beta_PR=beta_PR(1:iteration_ind-1); Direction=Direction(:,:,1:iteration_ind-1);
    num_iteration=iteration_ind-1;
end

% Create the function outputs 
X_final=XXX(:,end);
Y_final=YYY(:,end);
Z_final=ZZZ(:,end);
optm_loc=[X_final Y_final Z_final]

end

