% sort_cr.m selects events and station channels using the SAC files 
% according to the given criteria MIN_channel and MIN_event_per_channel. 
% For each station channel, crosscorrelation coefficient of all available 
% event pairs are computed and the maximum crosscorrelation coefficient of 
% each pair is found. The maximum crosscorrelation coefficient is then
% averaged over all channels that have recorded the given event pair. The
% average maximum crosscorrelation coefficients are then sorted in a
% descending order and sorted in max_cr.xls or max_cr.csv depending on the
% availability of Excel.


% Input:
% data_location                  directory storing the .SAC files                               

% MIN_channel                    minimum number of recording channels for an event to be considered

% MIN_event_per_channel          minimum number of events a channel records for the channel to be used

% xcorr_range                    part of waveform (in seconds) to compute crosscorrelation

% max_time_lag                   expected largest time-lag (in seconds) of waveforms from each other 


% Files generated:
% events_channels_selected.txt :          a list of the selected station
%                                         channels and the selected events 

% max_cr.xls (or .csv):                   average maximum crosscorrelation
%                                         coefficients in descending order

% file_indices.xls (or .csv):             the indices of the SAC files of the 
%                                         selected events and station channels


% Youqian Zhao, Sepetember 2017


%% Read in data from the SAC files
lis_t=dir(strcat(data_location,'*SAC'));
nfile=size(lis_t,1); 
sachead=read_sachead(strcat(data_location,lis_t(1).name));
ii=2;
for ii=2:nfile
    [sachead_temp] = read_sachead(strcat(data_location,lis_t(ii).name));
    sachead=cat(1,sachead,sachead_temp);
    ii=ii+1;
end
 
dt=sachead(1).times.delta; % acquire the sampling rate of the waveforms
xcorr_start_ind=xcorr_range(1)/dt+1; xcorr_end_ind=xcorr_range(2)/dt+1;
maxlag=ceil(max_time_lag/dt);


%% Find the available station channels 
% List all station channels in cell array channel_t
channel_t0=strcat(sachead(1).station.kstnm,sachead(1).stations.kcmpnm);
channel_t={channel_t0(find(~isspace(channel_t0)))};
% channel_t is a cell array listing all events represented by their recording station channel, corresponding to all SAC files
ii=2;
for ii=2:nfile
    channel_temp0=strcat(sachead(ii).station.kstnm,sachead(ii).stations.kcmpnm);
    channel_temp={channel_temp0(find(~isspace(channel_temp0)))};
    channel_t=cat(1,channel_t,channel_temp);
    ii=ii+1;
end

% Work out all the DIFFERENT station channels
channel_coll=channel_t(1); % channel_coll is a cell array listing all station channels with no repeat
nchannel=1;
ii=2;
for ii=2:nfile
    if ismember(channel_t(ii),channel_coll)==0
       nchannel=nchannel+1;
       channel_coll(nchannel)=channel_t(ii);        
    else    
    end
    ii=ii+1;
end
channel_coll=channel_coll';


%% Find the available events
% List all events in cell array event_t
% Use 3 digits to represent a day in a year (from 1 to 365), 6 digits for hour, minute, and secend
event_t={strcat(num2str(sachead(1).event.nzyear), num2str(sachead(1).event.nzjday,'%03i'),...
 num2str(sachead(1).event.nzhour,'%02i'), num2str(sachead(1).event.nzmin,'%02i'), num2str(sachead(1).event.nzsec,'%02i'))};
% event_t is a cell array listing all events represented by their occuring time, corresponding to all SAC files
ii=2;
for ii=2:nfile
    event_temp={strcat(num2str(sachead(ii).event.nzyear), num2str(sachead(ii).event.nzjday,'%03i'),...
        num2str(sachead(ii).event.nzhour,'%02i'), num2str(sachead(ii).event.nzmin,'%02i'), num2str(sachead(ii).event.nzsec,'%02i'))};
    event_t=cat(1,event_t,event_temp);
    ii=ii+1;
end

%  Work out all the DIFFERENT events
event_coll=event_t(1); % event_coll is a cell array listing all event occuring times with no repeat
nevent=1; 
ii=2;
for ii=2:nfile
    if ismember(event_t(ii),event_coll)==0
       nevent=nevent+1;
       event_coll(nevent)=event_t(ii);        
    else    
    end
    ii=ii+1;
end
event_coll=event_coll';


%% check the event and channel selection criteria are correct
if numel(channel_coll)<MIN_channel 
    error('Invalid value for MIN_channel. Only %d channels are found.',numel(channel_coll))
else;end
if numel(event_coll)<MIN_event_per_channel
    error('Invalid value for MIN_event_per_channel. Only %d events are found.',numel(event_coll))
else;end
    

%% For each event, work out the station channel that has recoreded it
channels_event_flag=zeros(nevent,nchannel); 
ii=1;
for ii=1:nevent
    event_I=event_coll{ii};
    jj=1;
    for jj=1:nfile
        event_J=event_t{jj};
        channel_J=channel_t{jj};
        if strcmp(event_I,event_J)==1
            kk=1;
            for kk=1:nchannel
                channel_K=channel_coll{kk};
                if strcmp(channel_J,channel_K)==1
                    channels_event_flag(ii,kk)=jj;
                else
                end
                kk=kk+1;
            end
        else
        end
        jj=jj+1;
    end
    ii=ii+1;
end


%% Select events whose number of time being recorded is greater than or equal to MIN_channel
n_recd=zeros(nevent,1); % number of times each event has been recorded
ii=1;
for ii=1:nevent
    n_recd(ii)=numel(find(channels_event_flag(ii,:)~=0));
ii=ii+1;
end
 
nevent_sel=0; % the number of events that have been recorded by at least MIN_channel times
ii=1;
for ii=1:nevent
    if n_recd(ii)>=MIN_channel
        nevent_sel=nevent_sel+1;
        event_sel(nevent_sel)=event_coll(ii);
        channels_event_sel_flag(nevent_sel,:)=channels_event_flag(ii,:);
    else
    end
    ii=ii+1;
end
event_sel=event_sel';


%% Select station channels that have recorded at least MIN_event_per_channel events
nchannel_sel=0;  % the number of station channels that have recorded at least MIN_event_per_channel events
ii=1;
for ii=1:nchannel
    if numel(find(channels_event_sel_flag(:,ii)~=0))>=MIN_event_per_channel
        nchannel_sel=nchannel_sel+1;
        channel_sel(nchannel_sel)= channel_coll(ii);
        channels_sel_event_sel_flag(:,nchannel_sel)=channels_event_sel_flag(:,ii);
    else
    end
    ii=ii+1;
end
channel_sel=channel_sel';


%% Compute the maximum of the crosscorrelation coefficient of all available pairs consisting of the selected events
% For each available pair among the selected events, the two events are represented by e1 and e2. 
% pair_sel_flag keeps a record of whether each specific waveform pair recorded by a given
% station channel exists (both e1 and e2 were recorded): 1 for existing, 0 for non-existing.
% max_cr_matrix stores the maximum of the crosscorrelation coefficient of
% all existing pairs, while for non-existing pairs, the value is 0. 
% pair_e1_e2 keeps a record of the index of the two events in pair. 
% channels_sel_event_sel_flag keeps a record of the index of the SAC files
% for each selected event recorded by each selcted station channel. The
% index used here is decided by how the user's system sorts the SAC files.
npair_sel=(nevent_sel-1)*nevent_sel/2;
pair_sel_flag=zeros(npair_sel,nchannel_sel); 
max_cr_matrix=zeros(npair_sel,nchannel_sel);
pair_e1_e2=zeros(npair_sel,2); % record the index
warning('off') 

kk=1;
for kk=1:nchannel_sel
    ind_e1=1;  ind_pair=1;  
    for ind_e1=1:nevent_sel-1
        ind_e2=ind_e1+1;
        for ind_e2=ind_e1+1:nevent_sel
            pair_e1_e2(ind_pair,1)=ind_e1;
            pair_e1_e2(ind_pair,2)=ind_e2;
            
            % both event are recorded by channel kk
            if channels_sel_event_sel_flag(ind_e1,kk)~=0 && channels_sel_event_sel_flag(ind_e2,kk)~=0 
                pair_sel_flag(ind_pair,kk)=1;
                % look for the SAC file for e1 in the current pair recorded by station kk
                event_tmp=event_t{1}; 
                channel_tmp=channel_t{1};
                event_e1=event_sel{ind_e1};
                channel_e1=channel_sel{kk};
                ind_lis=1;
                while strcmp(channel_tmp,channel_e1)==0 || strcmp(event_tmp,event_e1)==0
                    ind_lis=ind_lis+1;
                    channel_tmp0=strcat(sachead(ind_lis).station.kstnm,sachead(ind_lis).stations.kcmpnm);
                    channel_tmp={channel_tmp0(find(~isspace(channel_tmp0)))};
                    event_tmp={strcat(num2str(sachead(ind_lis).event.nzyear), num2str(sachead(ind_lis).event.nzjday,'%03i'),...
                        num2str(sachead(ind_lis).event.nzhour,'%02i'), num2str(sachead(ind_lis).event.nzmin,'%02i'), num2str(sachead(ind_lis).event.nzsec,'%02i'))};
                end
                filename_e1=lis_t(ind_lis).name;
                % look for the SAC file for e2 in the current pair recorded by station kk
                event_tmp=event_t{1}; 
                channel_tmp=channel_t{1};
                event_e2=event_sel{ind_e2};
                channel_e2=channel_sel{kk};
                ind_lis=1;
                while strcmp(channel_tmp,channel_e2)==0 || strcmp(event_tmp,event_e2)==0
                    ind_lis=ind_lis+1;
                    channel_tmp0=strcat(sachead(ind_lis).station.kstnm,sachead(ind_lis).stations.kcmpnm);
                    channel_tmp={channel_tmp0(find(~isspace(channel_tmp0)))};
                    event_tmp={strcat(num2str(sachead(ind_lis).event.nzyear), num2str(sachead(ind_lis).event.nzjday,'%03i'),...
                        num2str(sachead(ind_lis).event.nzhour,'%02i'), num2str(sachead(ind_lis).event.nzmin,'%02i'), num2str(sachead(ind_lis).event.nzsec,'%02i'))};
                end
                filename_e2=lis_t(ind_lis).name;
                
                % For an existing event pair, read seismic data from the SAC
                % files, compute there crosscorrelation coefficient within
                % the given range, find its maximum and store in max_cr_matrix
                [time,S1,hdrsac_S1] = read_sac(strcat(data_location,filename_e1));
                [time,S2,hdrsac_S2] = read_sac(strcat(data_location,filename_e2));
                [cr,lgs]=xcorr(S1(xcorr_start_ind:xcorr_end_ind),S2(xcorr_start_ind:xcorr_end_ind),maxlag,'coeff');
                max_cr_matrix(ind_pair,kk)=max(cr);
                
            else
            end
            ind_e2=ind_e2+1;
            ind_pair=ind_pair+1;
        end
        ind_e1=ind_e1+1;
    end
    kk=kk+1;
end


%% Take the average of maximum crosscorrelation coefficient over available channels
max_cr_avg=zeros(npair_sel,1);
ii=1;
for ii=1:npair_sel
    nchannel_recd=numel(find(max_cr_matrix(ii,:)~=0));
    max_cr_avg(ii)=sum(max_cr_matrix(ii,:))/nchannel_recd;
    ii=ii+1;
end

[MAX_cr,MAX_cr_ind]=sort(max_cr_avg,'descend');
% NB: max_corr is the un_sorted maximum of crosscorrelations, while MAX_cr is sorted.
Max_cr_pair=[pair_e1_e2(MAX_cr_ind,:) MAX_cr max_cr_matrix(MAX_cr_ind,:)];


%% Convert the occurring date of each event from 3 digits (from 1 to 365) into 4 digits (month and day)
ii=1;
for ii=1:nevent_sel
    year=event_sel{ii}(1:4); day=event_sel{ii}(5:7);
    hour=event_sel{ii}(8:9);minute=event_sel{ii}(10:11);second=event_sel{ii}(12:13);
    year_num=str2num(year);day_num=str2num(day);
    monthend=zeros(12,1);% the day number of the end of each month
    monthbegin=zeros(12,1);% the day number of the beginning of each month
    monthend(1)=eomday(year_num,1);monthbegin(1)=1;
    jj=2;
    for jj=2:12
        monthend(jj)=monthend(jj-1)+eomday(year_num,jj);
        monthbegin(jj)=monthend(jj-1)+1;
        jj=jj+1;
    end
    if day_num>=monthbegin(1) && day_num<=monthend(1)
        mm='01'; dd=num2str(day_num-monthbegin(1)+1,'%02i');
    elseif day_num>=monthbegin(2) && day_num<=monthend(2)
        mm='02'; dd=num2str(day_num-monthbegin(2)+1,'%02i');
    elseif day_num>=monthbegin(3) && day_num<=monthend(3)
        mm='03'; dd=num2str(day_num-monthbegin(3)+1,'%02i');
    elseif day_num>=monthbegin(4) && day_num<=monthend(4)
        mm='04'; dd=num2str(day_num-monthbegin(4)+1,'%02i');
    elseif day_num>=monthbegin(5) && day_num<=monthend(5)
        mm='05'; dd=num2str(day_num-monthbegin(5)+1,'%02i');
    elseif day_num>=monthbegin(6) && day_num<=monthend(6)
        mm='06'; dd=num2str(day_num-monthbegin(6)+1,'%02i');
    elseif day_num>=monthbegin(7) && day_num<=monthend(7)
        mm='07'; dd=num2str(day_num-monthbegin(7)+1,'%02i');
    elseif day_num>=monthbegin(8) && day_num<=monthend(8)
        mm='08'; dd=num2str(day_num-monthbegin(8)+1,'%02i');
    elseif day_num>=monthbegin(9) && day_num<=monthend(9)
        mm='09'; dd=num2str(day_num-monthbegin(9)+1,'%02i');
    elseif day_num>=monthbegin(10) && day_num<=monthend(10)
        mm='10'; dd=num2str(day_num-monthbegin(10)+1,'%02i');
    elseif day_num>=monthbegin(11) && day_num<=monthend(11)
        mm='11'; dd=num2str(day_num-monthbegin(11)+1,'%02i');
    elseif day_num>=monthbegin(12) && day_num<=monthend(12)
        mm='12'; dd=num2str(day_num-monthbegin(12)+1,'%02i');
    end
    event_sel_name(ii)={strcat(year,'-',mm,'-',dd,'-',hour,'-',minute,'-',second)};
    ii=ii+1;
end
event_sel_name=event_sel_name';


%% Generate output files and display running information 
% Creat a .txt file storing the selceted station channels and the selected
% events with the indices of the corresponding SAC files
d=dir('events_channels_selected.txt');
if size(d)~=0
    delete('events_channels_selected.txt');
else;end
file_generated0='events_channels_selected.txt';
fileID=fopen(file_generated0,'a');
ndigit=ceil(log10(nchannel_sel));
vartype=strcat('%0',num2str(ndigit),'i    %s\n');

ii=1;
for ii=1:nchannel_sel
    fprintf(fileID,vartype,ii,channel_sel{ii});
    ii=ii+1;
end
fprintf(fileID,'\n');

ndigit=ceil(log10(nevent_sel));
vartype=strcat('%0',num2str(ndigit),'i    %s\n');

ii=1;
for ii=1:nevent_sel
    fprintf(fileID,vartype,ii, event_sel_name{ii});
    ii=ii+1;
end
fclose(fileID);

% Save the indices of the SAC files of each selcted events and station channels
file_generated1='file_indices';
xlswrite(file_generated1,channels_sel_event_sel_flag)

% Save the sorted maximum crosscorrelation coefficients 
file_generated2='max_cr';
xlswrite(file_generated2,Max_cr_pair)

% Display running information and list files generated
fprintf('There are %d events and %d channels found.\n',numel(event_coll),numel(channel_coll))
fprintf('There are %d events and %d channels selected.\n',nevent_sel,nchannel_sel)
disp('Files generated:')
disp(file_generated0)
filedir1=dir('file_indices*');
filedir2=dir('max_cr*');
disp(filedir1.name)
disp(filedir2.name)


