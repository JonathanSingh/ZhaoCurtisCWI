function [ initial_loc ] = initialize_locations( x_range, y_range, z_range, num_event, MU_n )
% initialize_locations.m generates a set of initial locations for the 
% minimization problem solved by Source_Location.m. 

% It first creates a set of locations for the given event number, uniformly
% distributing in the given range. It then reorders the created events to 
% ensure the least square residuals of inter-source separations (residuals 
% being the difference in separation of each event pair between that 
% calculated from the created initial locations and that estimated with 
% coda wave interferometry (CWI) from seismic data).


% Input:
% x_range (y_range,z_range)      1 x 2 array, storing the range for 
%                                x (y,z) -coordinates

% num_event                      number of events in the given cluster

% MU_n                           N(N-1)/2 x 1 array,  storing the means of the CWI 
%                                separation estimates for all available event pairs,
%                                averaged over all channels if data from multiple 
%                                channels are used, with N being the number of events


% Output:
% initial_position               N x 3 array, storing the locations to be used as 
%                                initialization of the minimization problem
%                                      column 1 - x-coordinates
%                                      column 2 - y-coordinates
%                                      column 3 - z-coordinates


% Youqian Zhao, Sepetember 2017


% Create a set of event locations that are uniformly distributed
X0_original=x_range(1)+(x_range(2)-x_range(1)).*rand(num_event,1);
Y0_original=y_range(1)+(y_range(2)-y_range(1)).*rand(num_event,1);
Z0_original=z_range(1)+(z_range(2)-z_range(1)).*rand(num_event,1);

% Re-order the preliminary events
% Calculate the sum of squared residuals (SSR) of separations for all 
% possible event orders
num_pair=((num_event-1)+1)*(num_event-1)/2;
num_combination=(num_event-1)*num_event;
event_index_recorder=zeros(num_combination,num_event);
iii=1;
event_flag=1:1:num_event;
X0=X0_original; Y0=Y0_original; Z0=Z0_original;
for iii=1:num_event
    jjj=2;
    % Change event orders
    for jjj=2:num_event
        X0_temp=X0(iii);   Y0_temp=Y0(iii);   Z0_temp=Z0(iii);
        X0(iii)=X0(jjj);   Y0(iii)=Y0(jjj);   Z0(iii)=Z0(jjj);
        X0(jjj)=X0_temp; Y0(jjj)=Y0_temp; Z0(jjj)=Z0_temp;
        event_flag_temp=event_flag(iii);
        event_flag(iii)=event_flag(jjj);
        event_flag(jjj)=event_flag_temp;
        % Calculate source separations for the current event orders
        initial_S=zeros(num_pair,1);
        ii=1; jj=1; pair_index2=1;
        for ii=1:(num_event-1)
            for jj=(ii+1):num_event
                x=[X0(ii);X0(jj)];
                y=[Y0(ii);Y0(jj)];
                z=[Z0(ii);Z0(jj)];
                initial_S(pair_index2)=sqrt((x(1)-x(2)).^2+(y(1)-y(2)).^2+(z(1)-z(2)).^2);
                pair_index2=pair_index2+1;
            end 
        end 
        event_index_recorder((iii-1)*(num_event-1)+(jjj-1),:)=event_flag;
        % Calculate SSR for the current event orders
        SSR((iii-1)*(num_event-1)+(jjj-1))=sum((mean(MU_n,2)-initial_S).^2);
    end
end

% Find the ordering of the events that gives the least SSR
[min_SSR,min_SSR_index]=min(SSR)

% Re-order the events for least SSR
jj=1;
for jj=1:num_event
    X0(jj)=X0_original(event_index_recorder(min_SSR_index,jj));
    Y0(jj)=Y0_original(event_index_recorder(min_SSR_index,jj));
    Z0(jj)=Z0_original(event_index_recorder(min_SSR_index,jj));
end

% Generate output
initial_loc=[X0 Y0 Z0];

end

