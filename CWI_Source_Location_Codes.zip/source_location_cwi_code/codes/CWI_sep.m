function [ source_sep,sep_mean,sep_std ] = CWI_sep( S1,S2,time,dt,veloc,source_type, win_length,win_start,win_end,search_range,num_interpo_point)

% CWI_sep.m applies coda wave interferometry (CWI) (Snieder, 2006) to
% estimate the separation between a pair of sources with similar mechanisms
% for isotropic sources in a 2D or 3D acoustic medium, or double-couple
% sources in an elastic medium, assuming both sources are on the same side
% of fault plane (Snieder and Vijlandt, 2005).

% The following improvements introduced by Robinson et al. (2011) are
% applied:
% 1) removes the Taylor series approximation of the autocorrelation of
% waveforms of the two events, and which
% 2) applies a restricted searching range when searching for the maximum of
% correlation coefficient Rmax to avoid cycle skipping.


% Input:
% S1, S2               waveforms of the event pair
% time                 time series of waveforms
% dt                   length of interval between two samples in seconds
% veloc                seismic velocity in the source region
%                           - for acoustic media veloc is a scaler;
%                           - for elastic media, veloc is a 1x2 vector consisting of [P-wave-velocity S-wave-velocity]
% source_type          type of source mechanism and propagating medium
%                           - '2d' for isotropic sources in 2D an acoustic medium
%                           - '3d' for isotropic sources in 3D an acoustic medium
%                           - 'doublecouple' for double-couple sources in an elastic medium
% win_length           length of each time-window in coda
% win_start            starting time of windowing
% win_end              ending time of windowing
% search_range         number of data to search on each side of the point where time-shift is zero when
%                      searching for the maximum of the correlation coefficient (Rmax) for each time-window
% num_interpo_point    number of data to interpolate between adjacent samples when looking for Rmax for each time-window

% Output:
% source_sep           an array containing estimated source separation from all time-windows
% sep_mean             the mean of the estimated source separations
% sep_std              the standard deviation of the estimated source separations


% References:
%     Snieder, R., and M. Vrijlandt, 2005, Constraining the source separation
% with coda wave interferometry: Theory and application to earthquake
% doublets in the Hayward fault, California: Journal of Geophysical Research
% Solid Earth, 110, B04301.
%     Snieder, R., 2006, The theory of coda wave interferometry: Pure and
% Applied Geophysics, 163, 455-473.
%     Robinson, D. J., M. Sambridge, and R. Snieder, 2011, A probabilistic
% approach for estimating the separation between a pair of earthquakes
% directly from their coda waves: Journal of Geophysical Research, 116,1-14.


% Youqian Zhao, Sepetember 2017


%% Separate coda into time-windows
% Set the left-side boundary of each time window
num_windows=floor((win_end-win_start)/win_length);
win_left=zeros(num_windows,1);
win_left(1)=win_start;
i=2;
for i=2:num_windows
    win_left(i)=win_start+(i-1)*win_length;
    i=i+1;
end

% Set the right-side boundary of each time window
win_right=zeros(num_windows,1);
j=1;
for j=1:num_windows
    win_right(j)=win_left(j)+win_length;
    j=j+1;
end

% Calculate the sample indices of the left and right boundaries of each time-window in waveforms' coda
indexes=zeros(num_windows,2);
ii=1;
for ii=1:num_windows
    indexes(ii,1)=win_left(ii)/dt+1;  % the indices of left boundary of each time_window
    indexes(ii,2)=win_right(ii)/dt+1;
    ii=ii+1;
end

% Set time axis for each window
% windows is a matrix. Each row of it is the time axis for a time-window
windows=zeros(num_windows,floor(win_length/dt+1));
jj=1;
for jj=1:num_windows
    windows(jj,:)=[time(indexes(jj,1):indexes(jj,2))];
    jj=jj+1;
end

%% Compute correlation coefficient Rts
% Put seismic data into time_windows
% s1 and s2 have the same size with matrix windows. Each row of s1 (or s2)
% are the data in a time-window of waveform S1
s2=zeros(size(windows));
s1=zeros(size(windows));
ii=1;
for ii=1:num_windows
    s1(ii,:)=[S1(indexes(ii,1):indexes(ii,2))];
    s2(ii,:)=[S2(indexes(ii,1):indexes(ii,2))];
    ii=ii+1;
end

% Calulate the correlation coefficient Rts
Rts=zeros(num_windows,2*size(windows,2)-1);
Rts_numerator=zeros(num_windows,2*size(windows,2)-1);
Rts_denominator=zeros(num_windows,1);
ii=1;
for ii=1:num_windows
    Rts_numerator(ii,:)=xcorr(s1(ii,:),s2(ii,:));
    Rts_denominator(ii)=sqrt(xcorr(s1(ii,:),0)*xcorr(s2(ii,:),0));
    Rts(ii,:)=Rts_numerator(ii,:)./Rts_denominator(ii);
    ii=ii+1;
end

% Search for the maximum of correlation ceofficient Rmax for each time-window
mid_index_Rts=ceil(size(Rts,2)/2);
Rmax=zeros(num_windows,1);
Rmax_index=zeros(num_windows,1);
jj=1;
for j=1:num_windows
    % Apply a restricted search to avoid cycle skipping (Robinson et al. 2011)
    [Rmax(jj),Rmax_index(jj)]=max(Rts(jj,(mid_index_Rts-search_range:mid_index_Rts+search_range)));
    jj=jj+1;
end

%% Find the variance of travel-time difference
% Calculate the autocorrelation for each time-window
normalized_autocorrelation=zeros(num_windows,2*size(windows,2)-1);
ii=1;
for ii=1:size(normalized_autocorrelation,1)
    normalized_autocorrelation(ii,:)=xcorr(s1(ii,:),s1(ii,:))./xcorr(s1(ii,:),0);
    ii=ii+1;
end

% For each time-window, find the interval of the autocorrelation where Rmax falls in
Autocorr_search=zeros(num_windows,1);
ind_auto_max=size(s1,2);
ii=1;
for ii=1:num_windows 
    if normalized_autocorrelation(ii,ind_auto_max+1)<Rmax(ii) % if Rmax falls between where the time-shift of the autocorrelation is 0 and 1
        Autocorr_search(ii)=1;
    elseif normalized_autocorrelation(ii,ind_auto_max+1)==Rmax(ii) % if Rmax falls where the time-shift of the autocorrelation is 1
        Autocorr_search(ii)=2;
    else % if Rmax falls outside where the time-shift of the autocorrelation is 1
        
        % Find the first data of the autocorrelation where its value is lower than Rmax
        auto_current=normalized_autocorrelation(ii,ind_auto_max+1); % the value of the autocorrelation at the given time-shift being compared with Rmax
        num_from_max=2; % the number of data point away from (including) where the time-shift of the autocorrelation is 0
        while auto_current>Rmax(ii)
            auto_current=normalized_autocorrelation(ii,ind_auto_max+num_from_max);
            num_from_max=num_from_max+1;
        end
        num_from_max=num_from_max-1;
        Autocorr_search(ii)=num_from_max;
    end
    ii=ii+1;
end

% Apply linear interpolate inside the interval where Rmax falls in to find
% a more accurate value for sigma_t
ind_half_auto=size(s1,2);
ii=1;
for ii=1:num_windows
    interpo_high=normalized_autocorrelation(ii,ind_half_auto+Autocorr_search(ii)-1);
    interpo_low=normalized_autocorrelation(ii,ind_half_auto+Autocorr_search(ii));
    interpo_step=(interpo_high-interpo_low)/(num_interpo_point+1);
    interpo_dt=dt/(num_interpo_point+1);
    interpo_values=fliplr(interpo_low:interpo_step:interpo_high);
    diff_interpo_Rmax_nega_posi=interpo_values-Rmax(ii);
    diff_interpo_Rmax=abs(diff_interpo_Rmax_nega_posi);
    [min_diff min_diff_ind]=min(diff_interpo_Rmax);
    sigma_t(ii)=dt*(Autocorr_search(ii)-1)+interpo_dt*(min_diff_ind-1);
    if diff_interpo_Rmax_nega_posi(min_diff_ind)<0
        Rmax_close(ii)=Rmax(ii)-diff_interpo_Rmax(min_diff_ind);
    else
        Rmax_close(ii)=Rmax(ii)+diff_interpo_Rmax(min_diff_ind);
    end
    ii=ii+1;
end


%% Compute source separations
% Compute source separation for all time-windows according to the given source types
if strcmp(source_type,'2d')==1 % isotropic sources in 2D an acoustic medium
    source_sep=sqrt(2)*veloc*sigma_t;
elseif strcmp(source_type,'3d')==1 % isotropic sources in 3D an acoustic medium
    source_sep=sqrt(3)*veloc*sigma_t;
elseif strcmp(source_type,'doublecouple')==1 % double-couple sources in an elastic medium
    source_sep=sqrt(7*(2/veloc(1)^6+3/veloc(2)^6)/(6/veloc(1)^8+7/veloc(2)^8))*sigma_t;
else
    disp('Please choose the correct source type.')
end

% Compute the mean and the standard deviation of the separations
sep_mean=sum(source_sep)/num_windows;
sep_std=std(source_sep);

end

