function [ gradient ] = gradient_multi_channel( Xc,Yc,Zc,domin_wavelength,  a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs )
% gradient.m calculates the gradient of the joint likelihood function L at 
% the given point. L is a function of 3xN variables, where N is the number 
% of events to be located. Hence, the gradient of L consists of 3xN partial 
% derivatives of L, each in terms of a variable of L.

% The partial derivatives of L are computed using the common method:
% delta_L/delta_xi=(L(xi+h)-L(xi))/h,
% where the LHS represents the partial derivative of L in terms of variable
% xi, and h is an extremely small constant.

% Input:
% Xc (Yc,Zc)              x (y, z)-axis coordinates of the current location of
%                         events in the cluster
% domin_wavelength        dominate wavelength of the propagating waves

% a_mu1                   parameters of the empirical relations between true
%                         separation and the mean of the CWI estimates

% a_sigma1,c              parameters of the empirical relations between true
%                         separation and the standard deviation of the CWI estimates

% MU_n                    N(N-1)/2 x K array, each column storing the means of the
%                         CWI separation estimates for all available event pairs, with 
%                         N being the number of events, K being the number of channels

% SIGMA_n                 N(N-1)/2 x K array, each columnstoring the standard
%                         deviations of the CWI separation estimates for all available 
%                         event pairs

% discarded_pairs         indices of event pairs to be discarded
%                               []        - no pair to be discarded
%                               nx1 array - single channle case,
%                                           with n pair(s) to be discarded
%                               nxK array - K channle case,
%                                           with n being the largest number of pairs 
%                                           to be discarded for any individual channel


% Output:
% gradient                gradient of the joint likelihood function L at the given 
%                         point (Xc, Yc, Zc). A Nx3 matrix, with the 1st, 2nd, and 3rd 
%                         column storing the partial derivatives in terms of x, y and  
%                         z-coordinates of the event locations


% Scripts/Functions required:
% ln_joint_likelihood.m
% likelihood_individual.m


% Youqian Zhao, Sepetember 2017


%% Evaluate the joint likelihood fucntion L at the given point
Lc=ln_joint_likelihood( Xc,Yc,Zc,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs); 

%% Evaluate the partial derivatives
% Set an extremely small constant as the increment for computing partial derivatives
Xh=Xc; Yh=Yc; Zh=Zc;
h=1.0e-5;

% Decide the sizes of the relevant arrays
num_event=size(Xh,1);
L_X_h=zeros(size(Xh,1),1);
L_Y_h=zeros(size(Yh,1),1);
L_Z_h=zeros(size(Zh,1),1);
Xh=Xc; Yh=Yc; Zh=Zc; 

% Evaluate the partial derivatives in terms of x-coordinate of event locations
ind_x=1;
for ind_x=1:num_event
    Xh(ind_x)=Xc(ind_x)+h;
    L_X_h(ind_x)= ln_joint_likelihood( Xh,Yh,Zh,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n,discarded_pairs); 
    Xh(ind_x)=Xc(ind_x);  
end
DL_DX=(L_X_h-Lc)/h;

% Evaluate the partial derivatives in terms of y-coordinate of event locations
ind_y=1;
for ind_y=1:num_event
    Yh(ind_y)=Yc(ind_y)+h;
    L_Y_h(ind_y)= ln_joint_likelihood( Xh,Yh,Zh,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n,discarded_pairs); 
    Yh(ind_y)=Yc(ind_y);
end
DL_DY=(L_Y_h-Lc)/h;

% Evaluate the partial derivatives in terms of z-coordinate of event locations
ind_z=1;
for ind_z=1:num_event
    Zh(ind_z)=Zc(ind_z)+h;
    L_Z_h(ind_z)= ln_joint_likelihood( Xh,Yh,Zh,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n,discarded_pairs); 
    Zh(ind_z)=Zc(ind_z);
end
DL_DZ=(L_Z_h-Lc)/h;

% Create gradient with the partial derivatives
gradient=[DL_DX DL_DY DL_DZ];

end

