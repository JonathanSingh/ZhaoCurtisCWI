% plt_std_slice.m plots the given slice of STD_matrix_3D, specified with
% the starting time of windowing

% Input:
% plt_slice_start    the starting time of windoing, specifying which slice
%                    of STD_matrix_3D to plot

% Youqian Zhao, Sepetember 2017


%% Check the input is correct
if ismember(plt_slice_start,win_start_coll)==0
    error('The specified plt_slice_start does not exist, please choose from:\n %s',num2str(win_start_coll));
else
end


%% Plot the specified slice of STD_matrix_3D
% Extraxt the specified slice from STD_matrix_3D
slice_plt=(plt_slice_start-coda_start)/dl_coda_start+1;
C=STD_matrix_3D(:,:,slice_plt);

% Decide the plotting range
extra_plt_value=mean(mean(C));
C_large_1=[C ones(d1,1)*extra_plt_value];
C_large_2=[C_large_1; ones(1,d2+1)*extra_plt_value];
max_num_window=floor((coda_end-coda_start)/min_l_win);
if max_num_window>max_num_win_limit
    max_num_window=max_num_win_limit;
else
end
num_window_collection=[min_num_win:max_num_window];
pcolor_x=min_num_win:(max_num_window+1);
pcolor_y=min_l_win:dl_win:(l_win_possible(end)+dl_win);

% Plot the slice
figure,pcolor( pcolor_x, pcolor_y, C_large_2')
colorbar
daspect([2 1 1])
xlabel('Number of windows','fontsize',17)
ylabel('Length of windows (s)','fontsize',17)
figtitle=strcat('Coda from',{' '},num2str(plt_slice_start),'s');
title(figtitle,'fontsize',18)
set(gca,'xtick',pcolor_x(1:end-1)+0.5)
set(gca,'ytick',pcolor_y(1:end-1)+dl_win/2)
x_ticklabel=cellstr(num2str((pcolor_x(1:end-1)')));
y_ticklabel=cellstr(num2str((pcolor_y(1:end-1)')));
set(gca,'xticklabel',x_ticklabel)
set(gca,'yticklabel',y_ticklabel)
set(gca,'fontsize',17)


