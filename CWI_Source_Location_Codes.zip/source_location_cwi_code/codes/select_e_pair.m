% select_e_pair.m selects event pairs to be used for location estimation. 
% It identifies event pairs whose separation estimates are abnormally 
% unsuitable for the location algorithm, in that, the mean and/or standard 
% deviation of separation estimates are unrealistically too low or too high 
% based on empirical thresholds.


% Input:
% num_pair                number of total event pairs 

% num_channel             number of channels to be used

% domin_wavelength        1 x K array, storing the dominant wavelength of
%                         each channel, K being the number of channels

% MU_n                    N(N-1)/2 x K array, each column storing the means of the
%                         CWI separation estimates for all available event pairs, with 
%                         N being the number of events, K being the number of channels

% SIGMA_n                 N(N-1)/2 x K array, each column storing the standard
%                         deviations of the CWI separation estimates for all available 
%                         event pairs


% Output:
% discarded_pairs         indices of event pairs to be discarded
%                               []        - no pair to be discarded
%                               nx1 array - single channle case,
%                                           with n pair(s) to be discarded
%                               nxK array - K channle case,
%                                           with n being the largest number of pairs 
%                                           to be discarded for any individual channel


% Youqian Zhao, Sepetember 2017


%%
% Empirical thresholds
Appli_up_bound_mu=0.60;     Appli_low_bound_mu=0;
Appli_up_bound_sigma=0.17;  Appli_low_bound_sigma=0.001;

% Prepare data
sep_mean=MU_n;
sep_std=SIGMA_n;
sep_nor=zeros(num_pair,num_channel);
sep_nor_std=zeros(num_pair,num_channel);
ii=1;
for ii=1:num_channel
    sep_nor(:,ii)=sep_mean(:,ii)/domin_wavelength(ii);
    sep_nor_std(:,ii)=sep_std(:,ii)/domin_wavelength(ii);
    ii=ii+1;
end

% Identify unsuitable event pairs 
jj=1; available_sep_index_1=ones(num_channel,1);
for jj=1:num_channel   
    ii=1; 
for ii=1:num_pair
    if sep_nor(ii,jj)<=Appli_up_bound_mu & sep_nor(ii,jj)>Appli_low_bound_mu...
            sep_nor_std(ii,jj)<=Appli_up_bound_sigma & sep_nor_std(ii,jj)>Appli_up_bound_sigma;
        
        sep_nor_Reduced(available_sep_index_1(jj),jj)=sep_nor(ii,jj);
        sep_nor_std_Reduced(available_sep_index_1(jj),jj)=sep_nor_std(ii,jj);
        available_sep_index_1(jj)=available_sep_index_1(jj)+1;
    else;end
    ii=ii+1;
end
available_sep_index_1(jj)=available_sep_index_1(jj)-1;
jj=jj+1;
end

% Clarify the indexes of the discarded pairs to be fed into function L 
num_discarded_pairs=zeros(1,num_channel);
jj=1;
for jj=1:num_channel
    num_discarded_pairs(jj)=numel(find(sep_nor(:,jj)>Appli_up_bound_mu | sep_nor(:,jj)<Appli_low_bound_mu | ...
    sep_nor_std(:,jj)>Appli_up_bound_sigma | sep_nor_std(:,jj)<Appli_low_bound_sigma));
    jj=jj+1;
end
discarded_pairs=zeros(max(num_discarded_pairs),num_channel);
jj=1;
for jj=1:num_channel
    if num_discarded_pairs(jj)~=0        
        discarded_pairs(1:num_discarded_pairs(jj),jj)=find(sep_nor(:,jj)>Appli_up_bound_mu | sep_nor(:,jj)<Appli_low_bound_mu | ...
       sep_nor_std(:,jj)>Appli_up_bound_sigma | sep_nor_std(:,jj)<Appli_low_bound_sigma);
    else
    end
    jj=jj+1;
end

