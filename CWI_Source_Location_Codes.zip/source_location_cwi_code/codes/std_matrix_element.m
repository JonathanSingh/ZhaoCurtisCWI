% std_matrix_element.m calculates elements of STD_matrix_3D, with given
% [number, length, starting time] of time-windows.

% std_maxtrix_element.m is called in std_maxtrix_3d.m

% Scripts/Functions required:
% CWI_sep.m

% Output:
% STD_mean           an element of STD_matrix_3D, for the given parameter combination

% Youqian Zhao, Sepetember 2017


%% Decide the size of arrays appearing in the following calculations
nevent_actual=nevent-numel(non_event);
npair=(nevent_actual)*(nevent_actual-1)/2;
SEP=zeros(npair,num_win); 
sep_mean=zeros(npair,1);
sep_std=zeros(npair,1);


%% Calculate element of STD_matrix_3D that is within the searching range
% For each possible event pair, the first and second events are indicated
% with ind1 and ind2, respectively
ind1=1; ind_pair=1;
for ind1=1:nevent-1
    if ismember(ind1,non_event)==0 % if event ind1 exists
        S1=data_alinged(ind1,:);
        ind2=ind1+1;
        for ind2=ind1+1:nevent
            if ismember(ind2,non_event)==0 % if event ind2 exists
                S2=data_alinged(ind2,:);
                
                % Compute the inter-source separations, with mean and
                % standard deviations accross time-windows
                [ SEP(ind_pair,:),sep_mean(ind_pair), sep_std(ind_pair)] = CWI_sep( S1,S2,time,dt,veloc,source_type, ...
                    l_win,start_win,end_win,search_range,num_interpo_point);               
                
            else % if event ind2 doesn't exist
                % Mark separations and their mean and standard deviations with "-1"
                SEP(ind_pair,:)=-1*ones(1,num_win); sep_mean(ind_pair)=-1; sep_std(ind_pair)=-1; % all results set to -1
            end
            ind_pair=ind_pair+1;
            ind2=ind2+1;
        end
    else % if event ind1 doesn't exist
        % Mark separations and their mean and standard deviations with "-1"
        ind2=ind1+1;
        for ind2=ind1+1:nevent
            SEP(ind_pair,:)=-1*ones(1,num_win); sep_mean(ind_pair)=-1; sep_std(ind_pair)=-1; % all results set to -1
            ind_pair=ind_pair+1;
            ind2=ind2+1;
        end
    end
    ind1=ind1+1;
end

% Compute the average of standard deviations
if numel(non_event)==0 % if all events exist
    STD_mean=mean(sep_std);
else % if not all events exist
    sep_actual_std=sep_std(find(sep_std~=-1))
    STD_mean=mean(sep_actual_std);
end

