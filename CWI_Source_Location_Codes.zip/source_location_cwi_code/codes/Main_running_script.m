% This script allows users to set parameters and run each step one by one
%% 1.1 Select events and stations, and calculate crosscorrelations of waveforms for event clustering
clear all
data_location='../examples/ollerton_earthquakes_example/example_data/'; 
MIN_channel=2; % minimum number of recording channels for an event to be considered
MIN_event_per_channel=10; % minimum number of events a channel records for the channel to be used
xcorr_range=[10 30]; % part of waveform (in seconds) to compute crosscorrelation
max_time_lag=10; % expected largest time-lag (in seconds) for crosscorrelation
sort_cr
return
%% 1.2 Cluster events 
clear all
data_location='../examples/ollerton_earthquakes_example/example_data/';
max_cr_pair=load('max_cr.csv'); % maximum crosscorrelation coefficients used for clustering
load('file_indices.csv'); % indices of the SAC files of the selected events and station channels
MIN_corr=0.9; % threshold of maximum crosscorrelation coefficient to be considered for clustering
MIN_E_per_CLUSTER=5; % minimum number of event for a cluster
clustering

%% 2.1 Pick first arrivels of waveforms 
clear all
data_location='../examples/ollerton_earthquakes_example/example_data/';
txtfilename='files_cluster1_channel1.txt';
% txtfilename='files_cluster1_channel2.txt';
% txtfilename='files_cluster1_channel3.txt';

% txtfilename='files_cluster2_channel1.txt';
% txtfilename='files_cluster2_channel2.txt';
% txtfilename='files_cluster2_channel3.txt';
first_arrival_pick

%% 2.2 select parameters for the estimation of inter-source separations
clear all
first_arrival_ind=load('first_arrivals_cluster1_channel1.csv');
txtfilename='files_cluster1_channel1.txt';
data_location='../examples/ollerton_earthquakes_example/example_data/'; 
plt_examplary_wav % plot an examplary wavefrom
return

% Set range for searching the lowest average standard deviation of source separations
coda_start=16; % start of searching range of windowing (in seconds)
coda_end=40; % end of searching range of windowing (in seconds)
dl_coda_start=1; % increment of the start of windowing  
min_num_win=4; % minimum number of time-windows allowed
min_l_win=2.5; % minimum length of time-windows allowed
max_num_win_limit=7; % maximum number of time-windows allowed
dl_win=0.5; % increment of the length of time-windows to be searched
plt_flag='y'; % 'y' for plotting slice of the 3D std-matrix containing the lowest average standard deviation; ; 'n' for not plotting
save_flag='y'; % 'y' for saving the running; 'n' for not saving

% Inputs for running CWI_sep.m
veloc=[4200 2360]; % velocity of the source region
source_type='doublecouple'; % type of source mechanism and propagating medium
search_range=40; % number of data to search
num_interpo_point=10; % number of data to interpolate between adjacent samples when searching for Rmax in each time-window 
separation_parameters 
return

% Check other slices of the 3D std-matrix, specifying with the time when windowing starts
load('seps_param_cluster1_channel1.mat') % load the 3Dn STD-matrix from previous running
plt_slice_start=21; % starting time of windoing, specifying which slice of STD_matrix_3D to plot
plt_std_slice 

%% 2.3 Estimate inter-source separations
clear all
first_arrival_ind=load('first_arrivals_cluster1_channel1.csv');
txtfilename='files_cluster1_channel1.txt';
data_location='../examples/ollerton_earthquakes_example/example_data/'; % the directory storing the .SAC files
veloc=[4200 2360]; % velocity of the source region
source_type='doublecouple'; % type of source mechanism and propagating medium
search_range=40;  % number of data to search
num_interpo_point=10; % number of data to interpolate between adjacent samples when searching for Rmax in each time-window 
win_length=2.5; % length of each time-window in coda to apply CWI
win_start=19; % starting time of windowing
win_num=4; % number of time-windows to use
separations
% mean([sep_mean sep_std],1)

%% 3. Estimate relative locations
clear all
% Basic parameters
veloc=[4200 2360]; % velocity of the source region
domin_freq=[2.6 2.7 3.2]; % dominant frequency of each channel
domin_wavelength=veloc(2)./domin_freq; % compute dominant wavelength
nevent=11; % number of events to locate
num_channel=3; % number of channels to use
num_pair=(1+(nevent-1))*(nevent-1)/2; % compute number of event pairs
max_iteration=240; % maximum number of iteration allowed
L_tolerance=1e-5; % minimum decrease in the objective function, below which the iteration shall be terminated 

% Separation data
seps1=load('seps_cluster1_channel1.csv');
seps2=load('seps_cluster1_channel2.csv'); 
seps3=load('seps_cluster1_channel3.csv'); % load separation data for location
MU_n=[seps1(:,1) seps2(:,1) seps3(:,1)]; % means of separation estimated
SIGMA_n=[seps1(:,2) seps2(:,2) seps3(:,2)]; % standard deviations of separation estimated 
select_e_pair % select event pairs to use based on empirical thresholds
% discarded_pairs=zeros(max(num_discarded_pairs),num_channel); % If all event pairs are needed

% Initialization 
initial_loc=load('../examples/ollerton_earthquakes_example/generated_files/initial_location_cluster1.csv');
% To create other randomly distributed initial locations
% [ initial_position ] = initialize_locations( [0 80], [0 80], [0 80], nevent, MU_n )

% Source location
[ optm_loc, Func_L_add] = Source_Location( initial_loc,MU_n,SIGMA_n,...
    domin_wavelength,discarded_pairs,max_iteration,L_tolerance )

% Save location results
xlswrite('location_cluster1_3channels',optm_loc);

