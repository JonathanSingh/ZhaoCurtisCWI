function [ Ln_prob_joint] = ln_joint_likelihood( X,Y,Z,domin_wavelength,a_mu1,a_sigma1,c,MU_n,SIGMA_n, discarded_pairs)
% ln_joint_likelihood.m estimates the joint likelihood p.d.f.
% - L for a cluster of events. For each station channel, all available event
% pairs are considered, except for those instructed to be discarded in the
% input of the function.

% The actual value estimated by this function is the negative of the
% logarithm of the joint likelihood p.d.f, for the convenience for
% minimization (Robinson et al., 2013).

% The joint likelihood p.d.f. for data from multiple station channels (Zhao
% et al., 2017) is established by the multiplying the joint likelihood
% p.d.f.s of Robinson et al. (2013) estimated using data from single
% channels, each with their own dominant frequency (wavelength).


% Input:
% X (Y,Z)                 x (y, z)-axis coordinates of the location of
%                         events in the cluster

% domin_wavelength        dominate wavelength of the propagating waves

% a_mu1                   parameters of the empirical relation between true
%                         separation and the mean of the CWI estimates

% a_sigma1,c              parameters of the empirical relation between true
%                         separation and the standard deviation of the CWI estimates

% MU_n                    N(N-1)/2 x K array, each column storing the means of the
%                         CWI separation estimates for all available event pairs, with 
%                         N being the number of events, K being the number of channels

% SIGMA_n                 N(N-1)/2 x K array, each column storing the standard
%                         deviations of the CWI separation estimates for all available 
%                         event pairs

% discarded_pairs         indices of event pairs to be discarded
%                               []        - no pair to be discarded
%                               nx1 array - single channle case,
%                                           with n pair(s) to be discarded
%                               nxK array - K channle case,
%                                           with n being the largest number of pairs 
%                                           to be discarded for any individual channel


% Output:
% Ln_prob_joint           negative logarithm of the joint likelihood p.d.f. L for data from 
%                         multiple station channels (joint likelihood p.d.f. for data from 
%                         single channel if  data from only one channel are provided)


% Scripts/Functions required:
% likelihood_individual.m


% References:
%     Robinson, D. J., M. Sambridge, R. Snieder, and J. Hauser, 2013,
% Relocating a Cluster of Earthquakes Using a Single Seismic Station:
% Bulletin of the Seismological Society of America, 103, 3057-3072.
%     Zhao, Y., A. Curtis, and B. Baptie, 2017, Locating microseismic
% sources with a single seismometer channel using coda wave interferometry:
% Geophysics, 82, NO. 3, A19?A24, doi: 10.1190/GEO2016-0404.1.


% Youqian Zhao, Sepetember 2017


%% Evaluate the individual likelihood p.d.f.s for all event pairs for all station channels
% Decide the sizes of relevant variables
num_pair=((length(X)-1)+1)*(length(X)-1)/2;
num_channel=size(MU_n,2);
Ln_prob_joint=zeros(num_pair,1);
kk=1;
for kk=1:num_channel
    
    % For each event pair, assign the two events and the corresponding mean
    % and standard deviations of the CWI separation estimates
    ii=1; jj=1; pair_index=1;
    for ii=1:(size(X,1)-1)
        for jj=(ii+1):size(X,1)
            x=[X(ii);X(jj)];
            y=[Y(ii);Y(jj)];
            z=[Z(ii);Z(jj)];
            mu_n=MU_n(pair_index,kk );
            sigma_n=SIGMA_n(pair_index,kk );
            
            % Estimate the individual likelihood p.d.f. for the current
            % event pair
            prob_element(pair_index,kk)=likelihood_individual(x,y,z,domin_wavelength(kk),a_mu1,a_sigma1,c,mu_n,sigma_n);
            pair_index=pair_index+1;
        end
    end
    kk=kk+1;
end


%% Evaluate the joint likelihood p.d.f.
% Take the negative logarithm of the p.d.f.s
prob_element_logarithm=real(log(prob_element));

% Decide the event pairs to be considered when estimating joint likelihood p.d.f.s
for kk=1:num_channel % loop over channels
    if num_channel==1 % if there is only one channel
        if  numel(find(discarded_pairs~=0))==0   % if no event pairs to discard
            prob_element_logarithm_proper=prob_element_logarithm;
        else % if there are pairs to discard for the current channel
            pair_joint_ln_ind=1; pair_get_joint_ln_ind=0;
            for pair_joint_ln_ind=1:num_pair
                if ismember(pair_joint_ln_ind,discarded_pairs)==0
                    pair_get_joint_ln_ind=pair_get_joint_ln_ind+1;
                    prob_element_logarithm_proper(pair_get_joint_ln_ind)=prob_element_logarithm(pair_joint_ln_ind);
                else
                end
                pair_joint_ln_ind=pair_joint_ln_ind+1;
            end
        end
        
        % Compute the joint likelihood p.d.f.
        Ln_prob_joint_single_channel=-sum(prob_element_logarithm_proper);
       
        
    else % if there are multiple channels
        if  numel(find(discarded_pairs(:,kk)~=0))==0   % if no event pairs to discard for the current channel
            prob_element_logarithm_proper=prob_element_logarithm(:,kk);
        else % if there are pairs to discard for the current channel
            pair_joint_ln_ind=1; pair_get_joint_ln_ind=0;
            for pair_joint_ln_ind=1:num_pair
                if ismember(pair_joint_ln_ind,discarded_pairs(:,kk))==0
                    pair_get_joint_ln_ind=pair_get_joint_ln_ind+1;
                    prob_element_logarithm_proper(pair_get_joint_ln_ind)=prob_element_logarithm(pair_joint_ln_ind,kk);
                else
                end
                pair_joint_ln_ind=pair_joint_ln_ind+1;
            end
        end
        
        % Compute the joint likelihood p.d.f. for the current individual channel
        Ln_prob_joint_single_channel(kk)=-sum(prob_element_logarithm_proper);
        clear prob_element_logarithm_proper
        kk=kk+1;
    end
end

% Evaluate the joint likelihood p.d.f. for multiple channels
Ln_prob_joint=sum(Ln_prob_joint_single_channel);
end

